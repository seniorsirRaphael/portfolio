<?php
/**
 * Server-Sent Events (SSE) endpoint for real-time updates
 */

require_once '../config/db_connect.php';
require_once 'session_manager.php';

// Set headers for SSE
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no'); // Disable buffering for Nginx

// Initialize session
$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();

// Only allow authenticated users
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit();
}

$lastEventId = isset($_SERVER['HTTP_LAST_EVENT_ID']) ? $_SERVER['HTTP_LAST_EVENT_ID'] : 0;

// Close session to allow other requests
session_write_close();

// Disable time limit
set_time_limit(0);

// Function to send SSE message
function sendMessage($event, $data, $id = null) {
    if ($id) {
        echo "id: $id\n";
    }
    echo "event: $event\n";
    echo "data: " . json_encode($data) . "\n\n";
    ob_flush();
    flush();
}

// Main loop (run for 1 minute before reconnecting)
$startTime = time();
while (time() - $startTime < 60) {
    // Check for new notifications
    $stmt = $conn->prepare("
        SELECT notification_id, title, message, created_at 
        FROM tblNotifications 
        WHERE user_id = ? AND notification_id > ? AND is_read = 0
        ORDER BY created_at DESC
        LIMIT 1
    ");
    $stmt->bind_param('ii', $_SESSION['user_id'], $lastEventId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $notification = $result->fetch_assoc();
        $lastEventId = $notification['notification_id'];
        
        sendMessage('notification', [
            'id' => $notification['notification_id'],
            'title' => $notification['title'],
            'message' => $notification['message'],
            'time' => time_ago($notification['created_at'])
        ], $lastEventId);
    }
    
    // Check for new messages
    $stmt = $conn->prepare("
        SELECT message_id, subject, sent_at 
        FROM tblMessages 
        WHERE recipient_id = ? AND message_id > ? AND is_read = 0
        ORDER BY sent_at DESC
        LIMIT 1
    ");
    $stmt->bind_param('ii', $_SESSION['user_id'], $lastEventId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $message = $result->fetch_assoc();
        $lastEventId = $message['message_id'];
        
        sendMessage('message', [
            'id' => $message['message_id'],
            'subject' => $message['subject'],
            'time' => time_ago($message['sent_at'])
        ], $lastEventId);
    }
    
    // Sleep for 1 second before checking again
    sleep(1);
}

// Send keep-alive comment
echo ":keep-alive\n\n";
ob_flush();
flush();