<?php
class SessionManager {
    private $conn;
    private $timeout_duration = 1800; // 30 minutes
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    public function startSecureSession() {
        $sessionParams = session_get_cookie_params();
        session_set_cookie_params([
            'lifetime' => $this->timeout_duration,
            'path' => '/',
            'domain' => $_SERVER['HTTP_HOST'],
            'secure' => isset($_SERVER['HTTPS']),
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
        
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $this->checkSessionActivity();
    }
    
    private function checkSessionActivity() {
        if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $this->timeout_duration) {
            $this->destroySession();
            header("Location: login.php?error=session_expired");
            exit();
        }
        $_SESSION['LAST_ACTIVITY'] = time();
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['session_token']);
    }
    
    public function createLoginSession($user_id, $remember = false) {
        $session_token = bin2hex(random_bytes(32));
        $remember_token = $remember ? bin2hex(random_bytes(32)) : null;
        
        try {
            // Update user record
            $stmt = $this->conn->prepare("
                UPDATE tblUsers SET 
                    session_token = ?,
                    last_login = NOW(),
                    login_ip = ?,
                    remember_token = ?,
                    failed_login_attempts = 0,
                    account_locked_until = NULL
                WHERE user_id = ?
            ");
            $stmt->bind_param("sssi", $session_token, $_SERVER['REMOTE_ADDR'], $remember_token, $user_id);
            $stmt->execute();
            
            // Regenerate session ID
            session_regenerate_id(true);
            
            // Set session variables
            $_SESSION['user_id'] = $user_id;
            $_SESSION['session_token'] = $session_token;
            $_SESSION['LAST_ACTIVITY'] = time();
            
            // Set remember me cookie
            if ($remember && $remember_token) {
                $expiry = time() + 86400 * 30; // 30 days
                setcookie(
                    'remember_token',
                    $user_id . ':' . $remember_token,
                    $expiry,
                    '/',
                    $_SERVER['HTTP_HOST'],
                    true,
                    true
                );
            }
            
            return true;
        } catch (Exception $e) {
            error_log("Session creation error: " . $e->getMessage());
            return false;
        }
    }
    
    public function checkSession() {
        if (!$this->isLoggedIn()) {
            $this->tryRememberMeLogin();
        }
        
        if (!$this->isLoggedIn()) {
            $this->destroySession();
            header("Location: login.php?error=session_expired");
            exit();
        }
        
        // Validate session token against database
        try {
            $stmt = $this->conn->prepare("
                SELECT session_token, status 
                FROM tblUsers 
                WHERE user_id = ?
            ");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows !== 1 || $result->fetch_assoc()['session_token'] !== $_SESSION['session_token']) {
                throw new Exception("Invalid session token");
            }
        } catch (Exception $e) {
            $this->destroySession();
            header("Location: login.php?error=invalid_session");
            exit();
        }
    }
    
    private function tryRememberMeLogin() {
        if (empty($_COOKIE['remember_token'])) {
            return false;
        }
        
        list($user_id, $token) = explode(':', $_COOKIE['remember_token'], 2);
        
        try {
            $stmt = $this->conn->prepare("
                SELECT user_id, remember_token, status 
                FROM tblUsers 
                WHERE user_id = ? AND status = 'Active'
            ");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (hash_equals($user['remember_token'], hash('sha256', $token))) {
                    return $this->createLoginSession($user['user_id'], true);
                }
            }
        } catch (Exception $e) {
            error_log("Remember me login error: " . $e->getMessage());
        }
        
        // Clear invalid cookie
        setcookie('remember_token', '', time() - 3600, '/');
        return false;
    }
    
    public function destroySession() {
        if (isset($_SESSION['user_id'])) {
            try {
                $stmt = $this->conn->prepare("
                    UPDATE tblUsers SET 
                        session_token = NULL,
                        remember_token = NULL,
                        last_logout = NOW()
                    WHERE user_id = ?
                ");
                $stmt->bind_param("i", $_SESSION['user_id']);
                $stmt->execute();
            } catch (Exception $e) {
                error_log("Session cleanup error: " . $e->getMessage());
            }
        }
        
        $_SESSION = array();
        
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), 
                '', 
                time() - 42000,
                $params["path"], 
                $params["domain"],
                $params["secure"], 
                $params["httponly"]
            );
            setcookie('remember_token', '', time() - 3600, '/');
        }
        
        session_destroy();
    }
    
    public function requireRole($allowed_roles) {
        if (!isset($_SESSION['role_level']) || !in_array($_SESSION['role_level'], $allowed_roles)) {
            header("Location: unauthorized.php");
            exit();
        }
    }
}
?>