<?php
/**
 * Utility helper functions
 */

/**
 * Generate initials from a full name
 * @param string $name Full name
 * @return string Initials (2 characters max)
 */
function initials($name) {
    $initials = '';
    $words = explode(' ', trim($name));
    
    if (count($words) >= 2) {
        $initials = strtoupper(substr($words[0], 0, 1)) . strtoupper(substr(end($words), 0, 1));
    } else {
        $initials = strtoupper(substr($name, 0, 2));
    }
    
    return $initials;
}

/**
 * Convert datetime to "time ago" format
 * @param string $datetime MySQL datetime format
 * @return string Human readable time difference
 */
function time_ago($datetime) {
    $now = new DateTime;
    $then = new DateTime($datetime);
    $diff = $now->diff($then);
    
    if ($diff->y > 0) {
        return $diff->y . ' year' . ($diff->y > 1 ? 's' : '') . ' ago';
    } elseif ($diff->m > 0) {
        return $diff->m . ' month' . ($diff->m > 1 ? 's' : '') . ' ago';
    } elseif ($diff->d > 0) {
        return $diff->d . ' day' . ($diff->d > 1 ? 's' : '') . ' ago';
    } elseif ($diff->h > 0) {
        return $diff->h . ' hour' . ($diff->h > 1 ? 's' : '') . ' ago';
    } elseif ($diff->i > 0) {
        return $diff->i . ' minute' . ($diff->i > 1 ? 's' : '') . ' ago';
    } else {
        return 'Just now';
    }
}

/**
 * Sanitize output data
 * @param mixed $data Data to sanitize
 * @return mixed Sanitized data
 */
function sanitize_output($data) {
    if (is_array($data)) {
        return array_map('sanitize_output', $data);
    }
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

/**
 * Format currency
 * @param float $amount Amount to format
 * @param string $currency Currency symbol (default: KES)
 * @return string Formatted currency string
 */
function format_currency($amount, $currency = 'KES') {
    return $currency . ' ' . number_format((float)$amount, 2);
}

/**
 * Redirect with message
 * @param string $url Redirect destination
 * @param string $message Flash message
 * @param string $type Message type (success, error, etc.)
 */
function redirect($url, $message = null, $type = 'success') {
    if ($message) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header("Location: $url");
    exit();
}

/**
 * Get flash message and clear it
 * @return array|null Array with message and type, or null if none exists
 */
function get_flash_message() {
    if (isset($_SESSION['flash_message'])) {
        $message = $_SESSION['flash_message'];
        $type = $_SESSION['flash_type'] ?? 'info';
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        return ['message' => $message, 'type' => $type];
    }
    return null;
}