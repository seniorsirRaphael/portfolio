<?php
/**
 * Authentication functions
 */

/**
 * Check if user is logged in
 * @param mysqli $conn Database connection
 * @return bool True if logged in, false otherwise
 */
function is_logged_in($conn) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (!isset($_SESSION['user_id'], $_SESSION['session_token'])) {
        return false;
    }
    
    $user_id = $_SESSION['user_id'];
    $session_token = $_SESSION['session_token'];
    
    // Check if session token exists in database
    $stmt = $conn->prepare("SELECT session_token FROM tblUsers WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        return hash_equals($user['session_token'], $session_token);
    }
    
    return false;
}

/**
 * Check if user has required role level
 * @param mysqli $conn Database connection
 * @param int $required_level Minimum required role level
 * @return bool True if user meets role requirement
 */
function has_role($conn, $required_level) {
    if (!is_logged_in($conn)) {
        return false;
    }
    
    $user_id = $_SESSION['user_id'];
    
    $stmt = $conn->prepare("
        SELECT r.role_level 
        FROM tblUsers u
        JOIN tblRoles r ON u.role_id = r.role_id
        WHERE u.user_id = ?
    ");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        return $user['role_level'] >= $required_level;
    }
    
    return false;
}

/**
 * Generate secure password hash
 * @param string $password Plain text password
 * @return string Hashed password
 */
function generate_password_hash($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Verify password against hash
 * @param string $password Plain text password
 * @param string $hash Hashed password
 * @return bool True if password matches hash
 */
function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate CSRF token
 * @return string CSRF token
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Validate CSRF token
 * @param string $token Token to validate
 * @return bool True if valid
 */
function validate_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}