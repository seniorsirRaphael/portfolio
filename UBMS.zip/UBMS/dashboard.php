<?php
require_once 'config/db_connect.php';
require_once 'includes/session_manager.php';
require_once 'includes/helpers.php'; // For utility functions like initials(), time_ago()

$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();
$sessionManager->checkSession();

// Get user data
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT u.*, r.role_name, r.role_level, b.business_name, b.logo_path 
    FROM tblUsers u
    JOIN tblRoles r ON u.role_id = r.role_id
    LEFT JOIN tblBusinesses b ON u.business_id = b.business_id
    WHERE u.user_id = ?
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get business stats (if user belongs to a business)
$business_stats = [];
if ($user['business_id']) {
    $stats_query = "
        SELECT 
            (SELECT COUNT(*) FROM tblProducts WHERE business_id = ?) as product_count,
            (SELECT COUNT(*) FROM tblEmployees e JOIN tblUsers u ON e.user_id = u.user_id WHERE u.business_id = ?) as employee_count,
            (SELECT SUM(sale_total) FROM tblSales WHERE business_id = ? AND MONTH(sale_date) = MONTH(CURRENT_DATE())) as monthly_sales,
            (SELECT COUNT(*) FROM tblSales WHERE business_id = ? AND DATE(sale_date) = CURRENT_DATE()) as today_sales
    ";
    $stmt = $conn->prepare($stats_query);
    $stmt->bind_param('iiii', $user['business_id'], $user['business_id'], $user['business_id'], $user['business_id']);
    $stmt->execute();
    $business_stats = $stmt->get_result()->fetch_assoc();
}

// Get recent activities
$activities = [];
$activity_query = "
    SELECT * FROM (
        (SELECT 'Sale' as type, sale_id as id, sale_date as date, CONCAT('KES ', FORMAT(sale_total, 2)) as details 
         FROM tblSales 
         WHERE user_id = ? 
         ORDER BY sale_date DESC LIMIT 5)
        
        UNION ALL
        
        (SELECT 'Message' as type, message_id as id, sent_at as date, 
         CONCAT('From: ', (SELECT full_name FROM tblUsers WHERE user_id = sender_id)) as details
         FROM tblMessages 
         WHERE recipient_id = ? 
         ORDER BY sent_at DESC LIMIT 5)
    ) as combined 
    ORDER BY date DESC 
    LIMIT 5
";
$stmt = $conn->prepare($activity_query);
$stmt->bind_param('ii', $user_id, $user_id);
$stmt->execute();
$activities = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get unread notifications (fixed the error)
$unreadNotifications = [];
$notification_query = "
    SELECT notification_id, title, message, created_at, is_read 
    FROM tblNotifications 
    WHERE user_id = ? AND is_read = 0 
    ORDER BY created_at DESC 
    LIMIT 5
";
$stmt = $conn->prepare($notification_query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$unreadNotifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UBMS | <?= htmlspecialchars($user['business_name'] ?? 'Dashboard') ?></title>
    
    <!-- Modern CSS Framework -->
    <link href="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.0.0-beta.64/dist/shoelace/shoelace.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/dashboard.css">
    
    <!-- Charting Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>  
    
    <!-- Animation Library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
</head>
<body class="dashboard-layout">
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-content">
            <sl-spinner style="font-size: 3rem;"></sl-spinner>
            <p>Loading Dashboard...</p>
        </div>
    </div>

    <!-- Main Layout -->
    <div class="app-container">
        <!-- Modern Sidebar -->
        <aside class="app-sidebar">
            <div class="sidebar-header">
                <img src="<?= $user['logo_path'] ? 'uploads/'.htmlspecialchars($user['logo_path']) : 'assets/images/logo.png' ?>" 
                     alt="Business Logo" class="sidebar-logo">
                <h3><?= htmlspecialchars($user['business_name'] ?? 'UBMS Portal') ?></h3>
            </div>
            
            <sl-tab-group placement="start">
                <!-- Dashboard Tab -->
                <sl-tab slot="nav" panel="dashboard" active>
                    <sl-icon name="speedometer2"></sl-icon>
                    <span>Dashboard</span>
                </sl-tab>
                
                <!-- Business Management (Admin) -->
                <?php if ($user['role_level'] === 'SuperAdmin'): ?>
                <sl-tab slot="nav" panel="business">
                    <sl-icon name="building"></sl-icon>
                    <span>Businesses</span>
                </sl-tab>
                <?php endif; ?>
                
                <!-- POS (Cashier) -->
                <?php if ($user['role_name'] === 'Cashier'): ?>
                <sl-tab slot="nav" panel="pos">
                    <sl-icon name="cash-coin"></sl-icon>
                    <span>Point of Sale</span>
                </sl-tab>
                <?php endif; ?>
                
                <!-- Accounting -->
                <?php if ($user['role_name'] === 'Accountant'): ?>
                <sl-tab slot="nav" panel="accounting">
                    <sl-icon name="calculator"></sl-icon>
                    <span>Accounting</span>
                </sl-tab>
                <?php endif; ?>
                
                <!-- Inventory Management -->
                <?php if (in_array($user['role_name'], ['Manager', 'SuperAdmin'])): ?>
                <sl-tab slot="nav" panel="inventory">
                    <sl-icon name="boxes"></sl-icon>
                    <span>Inventory</span>
                </sl-tab>
                <?php endif; ?>
                
                <!-- Reports -->
                <?php if ($user['role_level'] >= 2): // For managers and above ?>
                <sl-tab slot="nav" panel="reports">
                    <sl-icon name="bar-chart-line"></sl-icon>
                    <span>Reports</span>
                </sl-tab>
                <?php endif; ?>
                
                <!-- Settings -->
                <sl-tab slot="nav" panel="settings">
                    <sl-icon name="gear"></sl-icon>
                    <span>Settings</span>
                </sl-tab>
            </sl-tab-group>
            
            <div class="sidebar-footer">
                <sl-button variant="primary" outline full href="logout.php">
                    <sl-icon name="box-arrow-right"></sl-icon>
                    Logout
                </sl-button>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="app-main">
            <!-- Top Navigation -->
            <header class="app-header">
                <div class="header-left">
                    <sl-button variant="default" circle id="sidebarToggle">
                        <sl-icon name="list"></sl-icon>
                    </sl-button>
                    <h2>Dashboard</h2>
                </div>
                
                <div class="header-right">
                    <!-- Notifications -->
                    <sl-dropdown>
                        <sl-button slot="trigger" variant="default" circle>
                            <sl-icon name="bell"></sl-icon>
                            <?php if (count($unreadNotifications) > 0): ?>
                            <sl-badge pill pulse><?= count($unreadNotifications) ?></sl-badge>
                            <?php endif; ?>
                        </sl-button>
                        <sl-menu>
                            <?php if (count($unreadNotifications) > 0): ?>
                                <?php foreach ($unreadNotifications as $notification): ?>
                                <sl-menu-item>
                                    <div class="notification-item">
                                        <strong><?= htmlspecialchars($notification['title']) ?></strong>
                                        <p><?= htmlspecialchars($notification['message']) ?></p>
                                        <small><?= time_ago($notification['created_at']) ?></small>
                                    </div>
                                </sl-menu-item>
                                <?php endforeach; ?>
                                <sl-menu-divider></sl-menu-divider>
                                <sl-menu-item href="notifications.php">
                                    <sl-icon name="bell-fill" slot="prefix"></sl-icon>
                                    View All Notifications
                                </sl-menu-item>
                            <?php else: ?>
                                <sl-menu-item disabled>
                                    <div class="notification-item">
                                        <p>No new notifications</p>
                                    </div>
                                </sl-menu-item>
                            <?php endif; ?>
                        </sl-menu>
                    </sl-dropdown>
                    
                    <!-- User Profile -->
                    <sl-dropdown>
                        <sl-avatar slot="trigger" 
                                 image="<?= $user['avatar_path'] ? 'uploads/'.htmlspecialchars($user['avatar_path']) : '' ?>" 
                                 initials="<?= htmlspecialchars(initials($user['full_name'])) ?>"
                                 style="--size: 40px; cursor: pointer;"></sl-avatar>
                        <sl-menu>
                            <sl-menu-item href="profile.php">
                                <sl-icon name="person" slot="prefix"></sl-icon>
                                My Profile
                            </sl-menu-item>
                            <sl-menu-item href="settings.php">
                                <sl-icon name="gear" slot="prefix"></sl-icon>
                                Settings
                            </sl-menu-item>
                            <sl-menu-divider></sl-menu-divider>
                            <sl-menu-item href="logout.php">
                                <sl-icon name="box-arrow-right" slot="prefix"></sl-icon>
                                Logout
                            </sl-menu-item>
                        </sl-menu>
                    </sl-dropdown>
                </div>
            </header>
            
            <!-- Dashboard Content -->
            <div class="app-content">
                <!-- Welcome Banner -->
                <div class="welcome-banner animate__animated animate__fadeIn">
                    <div class="welcome-content">
                        <h1>Welcome back, <?= htmlspecialchars($user['full_name']) ?>!</h1>
                        <p class="text-muted">
                            <?= date('l, F j, Y') ?>
                            <?php if ($user['business_id']): ?>
                                | <?= htmlspecialchars($user['business_name']) ?>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="welcome-actions">
                        <sl-button-group>
                            <sl-button variant="primary" id="quickActionBtn">
                                <sl-icon name="plus-circle" slot="prefix"></sl-icon>
                                Quick Action
                            </sl-button>
                            <sl-dropdown>
                                <sl-button slot="trigger" variant="primary" caret></sl-button>
                                <sl-menu>
                                    <?php if ($user['role_name'] === 'Cashier'): ?>
                                        <sl-menu-item value="new-sale">New Sale</sl-menu-item>
                                    <?php endif; ?>
                                    <?php if ($user['role_level'] >= 2): // For managers and above ?>
                                        <sl-menu-item value="add-product">Add Product</sl-menu-item>
                                        <sl-menu-item value="add-employee">Add Employee</sl-menu-item>
                                    <?php endif; ?>
                                    <sl-menu-item value="send-message">Send Message</sl-menu-item>
                                    <sl-menu-item value="generate-report">Generate Report</sl-menu-item>
                                </sl-menu>
                            </sl-dropdown>
                        </sl-button-group>
                    </div>
                </div>
                
                <!-- Role-Specific Dashboard Content -->
                <?php if ($user['role_name'] === 'Cashier'): ?>
                    <!-- POS Interface -->
                    <?php include 'modules/pos/pos_interface.php'; ?>
                
                <?php elseif ($user['role_name'] === 'Accountant'): ?>
                    <!-- Accounting Dashboard -->
                    <?php include 'modules/accounting/dashboard.php'; ?>
                
                <?php else: ?>
                    <!-- Default Dashboard -->
                    <div class="dashboard-grid">
                        <!-- Stats Cards -->
                        <div class="stats-grid">
                            <sl-card class="stat-card animate__animated animate__fadeInUp">
                                <div slot="header">
                                    <sl-icon name="box-seam"></sl-icon>
                                    <h3>Products</h3>
                                </div>
                                <h1><?= $business_stats['product_count'] ?? 0 ?></h1>
                                <small>Total Products</small>
                                <sl-button variant="text" size="small" href="products.php">
                                    View All
                                    <sl-icon name="arrow-right" slot="suffix"></sl-icon>
                                </sl-button>
                            </sl-card>
                            
                            <sl-card class="stat-card animate__animated animate__fadeInUp animate__delay-1s">
                                <div slot="header">
                                    <sl-icon name="people"></sl-icon>
                                    <h3>Employees</h3>
                                </div>
                                <h1><?= $business_stats['employee_count'] ?? 0 ?></h1>
                                <small>Total Employees</small>
                                <sl-button variant="text" size="small" href="employees.php">
                                    View All
                                    <sl-icon name="arrow-right" slot="suffix"></sl-icon>
                                </sl-button>
                            </sl-card>
                            
                            <sl-card class="stat-card animate__animated animate__fadeInUp animate__delay-2s">
                                <div slot="header">
                                    <sl-icon name="currency-exchange"></sl-icon>
                                    <h3>Monthly Sales</h3>
                                </div>
                                <h1>KES <?= number_format($business_stats['monthly_sales'] ?? 0, 2) ?></h1>
                                <small>Current Month</small>
                                <sl-button variant="text" size="small" href="sales.php">
                                    View Report
                                    <sl-icon name="arrow-right" slot="suffix"></sl-icon>
                                </sl-button>
                            </sl-card>
                            
                            <sl-card class="stat-card animate__animated animate__fadeInUp animate__delay-3s">
                                <div slot="header">
                                    <sl-icon name="calendar-day"></sl-icon>
                                    <h3>Today's Sales</h3>
                                </div>
                                <h1><?= $business_stats['today_sales'] ?? 0 ?></h1>
                                <small>Transactions Today</small>
                                <sl-button variant="text" size="small" href="sales.php?filter=today">
                                    View Details
                                    <sl-icon name="arrow-right" slot="suffix"></sl-icon>
                                </sl-button>
                            </sl-card>
                        </div>
                        
                        <!-- Charts -->
                        <div class="chart-row">
                            <sl-card class="chart-card animate__animated animate__fadeIn">
                                <div slot="header">
                                    <h3>Monthly Sales</h3>
                                    <sl-select value="this_month" size="small" style="width: 120px;">
                                        <sl-menu-item value="this_month">This Month</sl-menu-item>
                                        <sl-menu-item value="last_month">Last Month</sl-menu-item>
                                        <sl-menu-item value="this_year">This Year</sl-menu-item>
                                    </sl-select>
                                </div>
                                <canvas id="salesChart"></canvas>
                                <div slot="footer">
                                    <sl-button variant="text" size="small" href="reports.php?type=sales">
                                        View Full Report
                                    </sl-button>
                                </div>
                            </sl-card>
                            
                            <sl-card class="chart-card animate__animated animate__fadeIn animate__delay-1s">
                                <div slot="header">
                                    <h3>Inventory Status</h3>
                                    <sl-select value="all" size="small" style="width: 120px;">
                                        <sl-menu-item value="all">All</sl-menu-item>
                                        <sl-menu-item value="low">Low Stock</sl-menu-item>
                                        <sl-menu-item value="out">Out of Stock</sl-menu-item>
                                    </sl-select>
                                </div>
                                <div id="inventoryChart"></div>
                                <div slot="footer">
                                    <sl-button variant="text" size="small" href="inventory.php">
                                        Manage Inventory
                                    </sl-button>
                                </div>
                            </sl-card>
                        </div>
                        
                        <!-- Recent Activities & Quick Actions -->
                        <div class="action-row">
                            <sl-card class="activity-card animate__animated animate__fadeIn">
                                <div slot="header">
                                    <h3>Recent Activities</h3>
                                    <sl-button-group>
                                        <sl-button size="small">Today</sl-button>
                                        <sl-button size="small">Week</sl-button>
                                        <sl-button size="small">Month</sl-button>
                                    </sl-button-group>
                                </div>
                                <sl-tab-group>
                                    <sl-tab slot="nav" panel="all" active>All</sl-tab>
                                    <sl-tab slot="nav" panel="sales">Sales</sl-tab>
                                    <sl-tab slot="nav" panel="messages">Messages</sl-tab>
                                    
                                    <sl-tab-panel name="all">
                                        <?php foreach ($activities as $activity): ?>
                                        <div class="activity-item">
                                            <sl-icon name="<?= $activity['type'] === 'Sale' ? 'cash-stack' : 'chat-left-text' ?>"></sl-icon>
                                            <div class="activity-details">
                                                <p><?= htmlspecialchars($activity['details']) ?></p>
                                                <small><?= date('M j, g:i a', strtotime($activity['date'])) ?></small>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                        <?php if (empty($activities)): ?>
                                        <div class="empty-state">
                                            <sl-icon name="activity" style="font-size: 2rem;"></sl-icon>
                                            <p>No recent activities</p>
                                        </div>
                                        <?php endif; ?>
                                    </sl-tab-panel>
                                    
                                    <sl-tab-panel name="sales">
                                        <?php foreach ($activities as $activity): ?>
                                            <?php if ($activity['type'] === 'Sale'): ?>
                                            <div class="activity-item">
                                                <sl-icon name="cash-stack"></sl-icon>
                                                <div class="activity-details">
                                                    <p><?= htmlspecialchars($activity['details']) ?></p>
                                                    <small><?= date('M j, g:i a', strtotime($activity['date'])) ?></small>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </sl-tab-panel>
                                    
                                    <sl-tab-panel name="messages">
                                        <?php foreach ($activities as $activity): ?>
                                            <?php if ($activity['type'] === 'Message'): ?>
                                            <div class="activity-item">
                                                <sl-icon name="chat-left-text"></sl-icon>
                                                <div class="activity-details">
                                                    <p><?= htmlspecialchars($activity['details']) ?></p>
                                                    <small><?= date('M j, g:i a', strtotime($activity['date'])) ?></small>
                                                </div>
                                            </div>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </sl-tab-panel>
                                </sl-tab-group>
                                <div slot="footer">
                                    <sl-button variant="text" size="small" href="activities.php">
                                        View All Activities
                                    </sl-button>
                                </div>
                            </sl-card>
                            
                            <sl-card class="quick-actions-card animate__animated animate__fadeIn animate__delay-1s">
                                <div slot="header">
                                    <h3>Quick Actions</h3>
                                </div>
                                <div class="quick-actions-grid">
                                    <?php if ($user['role_name'] === 'Cashier'): ?>
                                        <sl-button variant="primary" outline full href="pos.php">
                                            <sl-icon name="cash-coin" slot="prefix"></sl-icon>
                                            New Sale
                                        </sl-button>
                                    <?php endif; ?>
                                    
                                    <?php if ($user['role_level'] >= 2): // For managers and above ?>
                                        <sl-button variant="primary" outline full href="products.php?action=add">
                                            <sl-icon name="plus-circle" slot="prefix"></sl-icon>
                                            Add Product
                                        </sl-button>
                                        
                                        <sl-button variant="primary" outline full href="employees.php?action=add">
                                            <sl-icon name="person-plus" slot="prefix"></sl-icon>
                                            Add Employee
                                        </sl-button>
                                    <?php endif; ?>
                                    
                                    <sl-button variant="primary" outline full href="messages.php?action=compose">
                                        <sl-icon name="envelope-plus" slot="prefix"></sl-icon>
                                        Send Message
                                    </sl-button>
                                    
                                    <sl-button variant="primary" outline full href="reports.php?action=generate">
                                        <sl-icon name="file-earmark-bar-graph" slot="prefix"></sl-icon>
                                        Generate Report
                                    </sl-button>
                                </div>
                            </sl-card>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Modern JavaScript Libraries -->
    <script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.0.0-beta.64/dist/shoelace/shoelace.esm.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/luxon@3.0.1/build/global/luxon.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="assets/js/dashboard.js"></script>
    <script src="assets/js/charts.js"></script>
    <script src="assets/js/pos.js"></script>
    
    <script>
    // Check for session timeout
    setInterval(function() {
        axios.get('includes/session_ping.php')
            .catch(function() {
                window.location.href = 'login.php?error=session_expired';
            });
    }, 300000); // Ping every 5 minutes
    
    // Initialize dashboard when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Hide loading overlay
        document.getElementById('loadingOverlay').style.display = 'none';
        
        // Initialize charts
        initSalesChart();
        initInventoryChart();
        
        // Setup event listeners
        setupSidebarToggle();
        setupPOSEventListeners();
        
        // Load real-time updates
        startRealTimeUpdates();
        
        // Quick action button handler
        document.getElementById('quickActionBtn').addEventListener('click', function() {
            // Default quick action based on role
            <?php if ($user['role_name'] === 'Cashier'): ?>
                window.location.href = 'pos.php';
            <?php else: ?>
                window.location.href = 'products.php?action=add';
            <?php endif; ?>
        });
    });
    
    // Show loading state during AJAX operations
    function showLoading() {
        document.getElementById('loadingOverlay').style.display = 'flex';
    }
    
    function hideLoading() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }
    
    // Real-time updates
    function startRealTimeUpdates() {
        const eventSource = new EventSource('includes/realtime_updates.php');
        
        eventSource.onmessage = function(e) {
            const data = JSON.parse(e.data);
            
            if (data.type === 'notification') {
                // Update notification badge
                const badge = document.querySelector('.header-right sl-badge');
                if (badge) {
                    badge.textContent = parseInt(badge.textContent || '0') + 1;
                }
                
                // Show toast notification
                const toast = Object.assign(document.createElement('sl-alert'), {
                    variant: 'primary',
                    closable: true,
                    duration: 5000,
                    innerHTML: `
                        <sl-icon name="bell" slot="icon"></sl-icon>
                        <strong>${data.title}</strong><br>
                        ${data.message}
                    `
                });
                
                document.body.appendChild(toast);
                toast.toast();
            }
        };
    }
    </script>
</body>
</html>