<?php
session_start();
require_once 'config/db_connect.php';

// Fetch all data in optimized query
$sql = "SELECT b.*, 
        (SELECT GROUP_CONCAT(p.product_id, '|', p.product_name, '|', p.product_code, '|', p.price, '|', p.quantity, '|', p.description SEPARATOR ';;') 
         FROM tblProducts p 
         WHERE p.business_id = b.business_id AND p.is_active = 1 
         ORDER BY p.price DESC LIMIT 4) AS products,
        (SELECT GROUP_CONCAT(u.full_name, '|', r.role_name, '|', u.email SEPARATOR ';;') 
         FROM tblUsers u 
         JOIN tblRoles r ON u.role_id = r.role_id 
         WHERE u.business_id = b.business_id AND r.role_level = 'Manager' 
         LIMIT 2) AS managers
        FROM tblBusinesses b 
        WHERE b.is_active = 1 
        ORDER BY b.business_name ASC";

$resultBusinesses = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UBMS | Businesses Overview</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.8/sweetalert2.min.css">
  <style>
    :root {
      --primary-color: #3498db;
      --hover-color: #2980b9;
      --dark-bg: #1a1a2e;
      --dark-card: #16213e;
    }
    body { 
      background-color: #f5f7fa; 
      transition: all 0.3s ease;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    .business-section { 
      margin-bottom: 60px; 
      transition: all 0.3s ease;
    }
    .product-card { 
      transition: all 0.3s ease; 
      height: 100%;
      border: none;
      border-radius: 10px;
      overflow: hidden;
    }
    .product-card:hover { 
      transform: translateY(-5px); 
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
    .dark-mode {
      background-color: var(--dark-bg);
      color: #e6e6e6;
    }
    .dark-mode .card {
      background-color: var(--dark-card);
      color: #e6e6e6;
    }
    .dark-mode .list-group-item {
      background-color: var(--dark-card);
      color: #e6e6e6;
      border-color: #2c3e50;
    }
    .loading-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255,255,255,0.9);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 9999;
      flex-direction: column;
    }
    .loading-spinner {
      width: 70px;
      height: 70px;
      border: 8px solid #f3f3f3;
      border-top: 8px solid var(--primary-color);
      border-radius: 50%;
      animation: spin 1.5s linear infinite;
    }
    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    .skeleton-loader {
      background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
      border-radius: 4px;
    }
    @keyframes shimmer {
      0% { background-position: 200% 0; }
      100% { background-position: -200% 0; }
    }
    .floating-action-btn {
      position: fixed;
      bottom: 30px;
      right: 30px;
      z-index: 99;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .product-badge {
      position: absolute;
      top: 10px;
      right: 10px;
      z-index: 2;
    }
    .business-logo {
      width: 80px;
      height: 80px;
      object-fit: cover;
      border-radius: 50%;
      border: 3px solid white;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .scroll-top-btn {
      opacity: 0;
      visibility: hidden;
      transition: all 0.3s ease;
    }
    .scroll-top-btn.visible {
      opacity: 1;
      visibility: visible;
    }
  </style>
</head>
<body>
  <!-- Modern Loading Overlay -->
  <div id="loadingOverlay" class="loading-overlay">
    <div class="loading-spinner mb-3"></div>
    <h4 class="text-primary">Loading UBMS Portal</h4>
    <p class="text-muted">Preparing your business dashboard...</p>
    <div class="progress mt-3" style="width: 300px; height: 6px;">
      <div id="loadingProgress" class="progress-bar progress-bar-striped progress-bar-animated" style="width: 0%"></div>
    </div>
  </div>

  <header class="bg-primary text-white p-3 d-flex justify-content-between align-items-center shadow-sm">
    <div class="d-flex align-items-center">
      <i class="fas fa-building me-2"></i>
      <h3 class="m-0">UBMS Portal</h3>
    </div>
    <div>
      <button id="themeToggle" class="btn btn-sm btn-outline-light me-2" title="Toggle Dark Mode">
        <i class="fas fa-moon"></i>
      </button>
      <a href="login.php" class="btn btn-outline-light">
        <i class="fas fa-sign-in-alt me-1"></i> Login
      </a>
    </div>
  </header>

  <main class="flex-grow-1">
    <section class="container my-5">
      <div class="text-center mb-5 animate__animated animate__fadeInDown">
        <h1 class="fw-bold display-5">Explore Businesses & Top Products</h1>
        <p class="lead text-muted">All listings are auto-generated from our system database.</p>
        
        <div class="col-lg-6 col-md-8 mx-auto mt-4">
          <div class="input-group shadow-sm">
            <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
            <input type="text" id="businessSearch" class="form-control border-start-0" placeholder="Search businesses by name, location or product...">
            <button class="btn btn-primary" type="button" id="searchBtn">Search</button>
          </div>
        </div>
      </div>

      <!-- Filters Row -->
      <div class="row mb-4 g-3">
        <div class="col-md-3">
          <select class="form-select" id="businessTypeFilter">
            <option value="">All Business Types</option>
            <option value="Retail">Retail</option>
            <option value="Hospitality">Hospitality</option>
            <option value="Service">Service</option>
            <option value="Manufacturing">Manufacturing</option>
          </select>
        </div>
        <div class="col-md-3">
          <select class="form-select" id="productSort">
            <option value="price_desc">Highest Price</option>
            <option value="price_asc">Lowest Price</option>
            <option value="stock_desc">Most Stock</option>
          </select>
        </div>
        <div class="col-md-6 text-end">
          <button class="btn btn-outline-primary me-2" id="resetFilters">
            <i class="fas fa-undo me-1"></i> Reset
          </button>
        </div>
      </div>

      <?php if ($resultBusinesses->num_rows > 0): ?>
        <div class="row" id="businessContainer">
          <?php while ($business = $resultBusinesses->fetch_assoc()): ?>
            <div class="col-lg-6 mb-4 business-card" 
                 data-type="<?= htmlspecialchars($business['business_type']) ?>"
                 data-name="<?= htmlspecialchars(strtolower($business['business_name'])) ?>"
                 data-location="<?= htmlspecialchars(strtolower($business['location'])) ?>">
              <div class="card h-100 border-0 shadow-sm animate__animated animate__fadeIn">
                <div class="card-body">
                  <div class="d-flex align-items-start mb-4">
                    <img src="uploads/<?= htmlspecialchars($business['logo_path'] ?? 'default_logo.png') ?>" 
                         alt="<?= htmlspecialchars($business['business_name']) ?> Logo" 
                         class="me-3 business-logo">
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between align-items-start">
                        <h4 class="mb-1"><?= htmlspecialchars($business['business_name']) ?></h4>
                        <span class="badge bg-primary"><?= htmlspecialchars($business['business_type']) ?></span>
                      </div>
                      <div class="d-flex align-items-center text-muted mb-2">
                        <i class="fas fa-map-marker-alt me-1"></i>
                        <small><?= htmlspecialchars($business['location']) ?></small>
                      </div>
                      <div class="d-flex align-items-center text-muted">
                        <i class="fas fa-envelope me-1"></i>
                        <small><?= htmlspecialchars($business['contact_email']) ?></small>
                      </div>
                    </div>
                  </div>

                  <h5 class="text-success mb-3"><i class="fas fa-star me-1"></i> Featured Products</h5>
                  <div class="row g-3 mb-4">
                    <?php 
                    $products = explode(';;', $business['products'] ?? '');
                    foreach ($products as $productStr): 
                      if (empty($productStr)) continue;
                      $product = explode('|', $productStr);
                      if (count($product) < 6) continue;
                    ?>
                      <div class="col-md-6 col-lg-3">
                        <div class="card product-card h-100 shadow-sm position-relative">
                          <?php if ($product[4] <= 0): ?>
                            <span class="product-badge badge bg-danger">Sold Out</span>
                          <?php elseif ($product[4] < 5): ?>
                            <span class="product-badge badge bg-warning text-dark">Low Stock</span>
                          <?php endif; ?>
                          <div class="card-body">
                            <h6 class="card-title"><?= htmlspecialchars($product[1]) ?></h6>
                            <p class="text-muted small mb-2"><?= htmlspecialchars($product[5]) ?></p>
                            <p class="text-muted small mb-1">Code: <?= htmlspecialchars($product[2]) ?></p>
                            <p class="h5 text-primary mb-2">KES <?= number_format($product[3], 2) ?></p>
                            <p class="small mb-0 <?= $product[4] > 0 ? 'text-success' : 'text-danger' ?>">
                              <i class="fas fa-<?= $product[4] > 0 ? 'check' : 'times' ?> me-1"></i>
                              <?= $product[4] > 0 ? "In Stock ($product[4])" : "Out of Stock" ?>
                            </p>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>

                  <h6 class="text-primary mb-3"><i class="fas fa-user-tie me-1"></i> Management Contacts</h6>
                  <div class="row">
                    <?php 
                    $managers = explode(';;', $business['managers'] ?? '');
                    foreach ($managers as $managerStr): 
                      if (empty($managerStr)) continue;
                      $manager = explode('|', $managerStr);
                      if (count($manager) < 3) continue;
                    ?>
                      <div class="col-md-6 mb-3">
                        <div class="card border-0 shadow-sm">
                          <div class="card-body py-2">
                            <div class="d-flex align-items-center">
                              <div class="me-3">
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                  <i class="fas fa-user-tie"></i>
                                </div>
                              </div>
                              <div>
                                <h6 class="mb-0"><?= htmlspecialchars($manager[0]) ?></h6>
                                <small class="text-muted"><?= htmlspecialchars($manager[1]) ?></small>
                                <div class="d-flex align-items-center mt-1">
                                  <i class="fas fa-envelope text-muted me-2 small"></i>
                                  <small class="text-muted"><?= htmlspecialchars($manager[2]) ?></small>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    <?php endforeach; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <div class="text-center py-5">
          <div class="animate__animated animate__bounceIn">
            <i class="fas fa-building fa-4x text-muted mb-4"></i>
            <h3 class="mb-3">No Active Businesses Found</h3>
            <p class="text-muted lead">Check back later or contact the system administrator</p>
            <button class="btn btn-primary mt-3" id="refreshPage">
              <i class="fas fa-sync-alt me-1"></i> Refresh Page
            </button>
          </div>
        </div>
      <?php endif; ?>
    </section>
  </main>

  <!-- Floating Action Button -->
  <button id="scrollTopBtn" class="floating-action-btn btn btn-primary scroll-top-btn">
    <i class="fas fa-arrow-up"></i>
  </button>

  <footer class="bg-dark text-white py-4">
    <div class="container">
      <div class="row">
        <div class="col-md-4 mb-3">
          <h5>UBMS Portal</h5>
          <p class="small text-muted">Universal Business Management System for all your enterprise needs.</p>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Quick Links</h5>
          <ul class="list-unstyled">
            <li><a href="#" class="text-muted small">About UBMS</a></li>
            <li><a href="#" class="text-muted small">Contact Support</a></li>
            <li><a href="#" class="text-muted small">Privacy Policy</a></li>
          </ul>
        </div>
        <div class="col-md-4 mb-3">
          <h5>Connect With Us</h5>
          <div class="d-flex gap-3">
            <a href="#" class="text-muted"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="text-muted"><i class="fab fa-twitter"></i></a>
            <a href="#" class="text-muted"><i class="fab fa-linkedin-in"></i></a>
          </div>
        </div>
      </div>
      <hr class="my-3 bg-secondary">
      <div class="text-center">
        <p class="small mb-0">&copy; <?= date('Y') ?> Universal Business Management System (UBMS). All rights reserved.</p>
      </div>
    </div>
  </footer>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.8/sweetalert2.min.js"></script>
  <script>
    $(document).ready(function(){
      // Simulate loading progress
      let progress = 0;
      const progressInterval = setInterval(function() {
        progress += Math.random() * 10;
        if (progress >= 100) {
          progress = 100;
          clearInterval(progressInterval);
        }
        $('#loadingProgress').css('width', progress + '%');
      }, 200);

      // Hide loading overlay when everything is ready
      $(window).on('load', function(){
        setTimeout(function(){
          $('#loadingOverlay').fadeOut('slow', function(){
            $(this).remove();
          });
        }, 800);
      });

      // Scroll to top button
      $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
          $('#scrollTopBtn').addClass('visible');
        } else {
          $('#scrollTopBtn').removeClass('visible');
        }
      });

      $('#scrollTopBtn').click(function(){
        $('html, body').animate({scrollTop: 0}, 'smooth');
        return false;
      });

      // Enhanced search functionality
      $('#businessSearch, #searchBtn').on('input click', function() {
        const searchTerm = $('#businessSearch').val().toLowerCase();
        const businessType = $('#businessTypeFilter').val();
        
        $('.business-card').each(function() {
          const businessName = $(this).data('name');
          const businessLocation = $(this).data('location');
          const businessTypeValue = $(this).data('type');
          
          const nameMatch = businessName.includes(searchTerm);
          const locationMatch = businessLocation.includes(searchTerm);
          const typeMatch = businessType === '' || businessTypeValue === businessType;
          
          $(this).toggle((nameMatch || locationMatch) && typeMatch);
        });
      });

      // Business type filter
      $('#businessTypeFilter').change(function(){
        $('#businessSearch').trigger('input');
      });

      // Product sort
      $('#productSort').change(function(){
        // This would be implemented with AJAX in a real application
        Swal.fire({
          title: 'Sorting Coming Soon',
          text: 'Product sorting will be available in the next update',
          icon: 'info',
          confirmButtonText: 'OK'
        });
      });

      // Reset filters
      $('#resetFilters').click(function(){
        $('#businessSearch').val('');
        $('#businessTypeFilter').val('');
        $('#productSort').val('price_desc');
        $('.business-card').show();
      });

      // Theme toggle with localStorage persistence
      if (localStorage.getItem('darkMode') === 'true') {
        $('body').addClass('dark-mode');
        $('#themeToggle i').removeClass('fa-moon').addClass('fa-sun');
      }

      $('#themeToggle').click(function(){
        $('body').toggleClass('dark-mode');
        const icon = $(this).find('i');
        if ($('body').hasClass('dark-mode')) {
          icon.removeClass('fa-moon').addClass('fa-sun');
          localStorage.setItem('darkMode', 'true');
        } else {
          icon.removeClass('fa-sun').addClass('fa-moon');
          localStorage.setItem('darkMode', 'false');
        }
      });

      // Product card hover effects
      $('.product-card').hover(
        function() {
          $(this).addClass('shadow-lg');
          $(this).find('.card-body').css('transform', 'translateY(-3px)');
        },
        function() {
          $(this).removeClass('shadow-lg');
          $(this).find('.card-body').css('transform', 'translateY(0)');
        }
      );

      // Refresh page button
      $('#refreshPage').click(function(){
        location.reload();
      });

      // Tooltips
      $('[title]').tooltip({
        trigger: 'hover',
        placement: 'top'
      });
    });
  </script>
</body>
</html>