📁 index.php
Purpose: Landing/login page

Contains: Login form, authentication logic call

📁 dashboard.php
Purpose: Main dashboard (role-based)

Contains: Cards, analytics, menus based on role (Admin, Manager, Employee)

📁 config.php
Purpose: Database connection

Contains: MySQL connection settings

📁 session.php
Purpose: Session checker and role verification

Contains: Access control for each page

📁 logout.php
Purpose: Session destroyer

Contains: Log out and redirect

👥 User & Role Management
📁 users/
create_user.php – form to add users

edit_user.php – update user info

view_users.php – list all users

delete_user.php – user removal logic

📁 roles/
manage_roles.php – create/edit/delete roles

assign_roles.php – assign users to roles

🏢 Business & Profile Management
📁 business/
create_business.php – form to register business

edit_business.php – update business info

business_profile.php – view profile page

upload_logo.php – logo management

📦 Inventory Management
📁 inventory/
add_product.php – form to add product

edit_product.php – update product info

product_list.php – list all products

category_manager.php – manage categories

stock_entry.php – receive new stock

adjust_stock.php – correct stock manually

product_images.php – upload/manage multiple images

💸 Sales & Transactions
📁 sales/
create_sale.php – add sale

sales_history.php – sales records

receipt.php – print/download receipt

sales_report.php – generate reports (filters, graphs)

👨‍💼 Employees & Payroll
📁 employees/
add_employee.php – register employee

edit_employee.php – update employee

view_employees.php – list

assign_department.php – link to departments

📁 payroll/
salary_structure.php – define salaries

generate_payroll.php – run monthly payroll

view_slips.php – downloadable salary slips

payroll_status.php – track paid/pending

📣 Communication
📁 messaging/
send_message.php – send message to staff

view_messages.php – inbox

announcement_board.php – global announcements

📂 File & Upload Handling
📁 uploads/
upload_handler.php – upload logic for files/images

manage_documents.php – view/delete documents

🌐 Public Business Page (Frontend)
📁 public/
business.php?biz_id=xyz – public profile

product_showcase.php – public product listing

contact_business.php – send inquiry

announcement.php – public messages/alerts

📊 Reports & Analytics
📁 reports/
kpi_dashboard.php – key metrics

financial_summary.php – revenue/expense overview

user_activity_logs.php – audit logs

system_usage.php – login stats, business growth

🛠️ System Settings & Utilities
📁 settings/
general_settings.php – currency, time zone

backup_restore.php – database backup tool

admin_controls.php – system-wide toggles

🌈 Assets
📁 assets/css/
style.css – custom styling

admin.css – admin panel UI

responsive.css – mobile-first styling

📁 assets/js/
main.js – core JS functions (modals, alerts)

charts.js – graphs using Chart.js or ApexCharts

ajax_calls.js – for form submissions, table reloads

📁 assets/images/
Logos, product images, icons, profile pictures



📦 UBMS/
├── 📂 admin/                # Super-admin exclusive features
├── 📂 api/                  # Future REST API endpoints
├── 📂 assets/               # Static files
│   ├── 📂 css/
│   ├── 📂 js/
│   └── 📂 images/
├── 📂 includes/             # Reusable components
│   ├── 📜 auth_functions.php
│   └── 📜 db_operations.php
├── 📂 uploads/              # User-generated content
│   ├── 📂 business_logos/
│   └── 📂 payroll_slips/
└── 📜 .htaccess             # Security/redirect rules

📦 users/
├── 📜 create_user.php      # Form + validation logic
├── 📜 view_users.php       # Paginated table with search
└── 📜 audit_logs.php       # Track user actions (hidden from UI)

📦 inventory/
├── 📜 stock_entry.php      # Barcode/QR scan support
└── 📜 low_stock_alerts.php # Cron-job for notifications

📦 sales/
├── 📜 receipt.php          # Thermal printer formatting
└── 📜 void_sale.php        # Approval workflow for refunds

📦 employees/
├── 📜 clock_in_out.php     # Geolocation verification
└── 📜 payroll_status/      # Mobile-optimized for cleaners/security
    ├── 📜 index.php        # Simplified payroll view
    └── 📜 download_slip.php# PDF generation
	
📦 uploads/
├── 📜 image_compress.php   # Auto-resize product images
└── 📜 virus_scan.php       # ClamAV integration
📦 public/
├── 📜 .htaccess           # Prevent directory listing
└── 📜 product_showcase.php# SEO-friendly URLs (/biz/15/product/39)