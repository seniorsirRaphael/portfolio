**Universal Business Management System (UBMS) - Full Project Documentation**

---

## 1. System Overview

**Project Name:** Universal Business Management System (UBMS)
**Purpose:** A centralized, scalable platform to manage multiple businesses' operations including inventory, sales, HR/payroll, file management, public advertisements, and internal communication. The system offers role-based access control and caters to businesses of different sizes with mobile-friendly interfaces for ease of use.

### Core Functionalities:

* Multi-business support (one admin, many businesses)
* Role-based access control: Super Admin, Business Owner/Manager, Employee, Non-Database Staff
* Financial tracking (sales, expenses, payroll, profit)
* Inventory and sales analytics
* Public-facing business pages for showcasing products and announcements
* Employee management (HR, payroll, messaging)
* File/document/image uploads and management
* Non-database staff payroll & communication interface

---

## 2. User Roles & Interfaces

### A. Super Admin

* Access to all businesses
* Manage global settings, businesses, users, and roles
* View global financial metrics and KPIs

### B. Business Owner/Manager

* Access to own business only
* Manage finances, inventory, employees, roles, sales reports
* Post public ads/announcements

### C. Employee (Role-based access)

* Access depends on role (Cashier, Inventory Clerk, etc.)
* View tasks, enter sales, check stock, access salary slips

### D. Non-Database Staff (Cleaners, Security, etc.)

* Limited to:

  * Viewing payroll status and downloading slips
  * Receiving text/image messages
  * Viewing announcements
* Mobile-first interface for ease of access

---

## 3. Data Management

### Supported File Types:

* **Images:** .jpg, .png (for products, logos, profiles)
* **Documents:** .pdf (salary slips, ID uploads, receipts)

### File Storage:

* Files stored in server folders (e.g., `/uploads/business_101/products/`)
* MySQL stores metadata and file paths

### Upload Rules:

* Max image size: 5MB (auto-compression supported)
* Secure naming and storage path

---

## 4. Non-Database Staff Features

### Payroll Status Page:

* Monthly breakdowns (Paid, Pending, Rejected)
* PDF slip download option

### Messaging System:

* Text and image messages from managers
* Announcements board for shifts, alerts, general info

### Interface:

* Mobile-optimized login
* Tabs: "My Payroll", "Messages", "Announcements"

---

## 5. Technical Specifications

* **Backend:** PHP + MySQL
* **Frontend:** HTML5, CSS3, Bootstrap/Tailwind, JavaScript
* **Authentication:** Hashed passwords, session-based login
* **APIs:** RESTful endpoints for mobile app connectivity (future scope)
* **Database Management:** MySQL relational database with proper indexing

---

## 6. Database Schema

### 6.1 Core Tables

* `tblBusinesses`
* `tblUsers`
* `tblRoles`
* `tblUserRoles`
* `tblPermissions`

### 6.2 Inventory Management

* `tblCategories`
* `tblProducts`
* `tblProductImages`
* `tblStockEntries`
* `tblStockAdjustments`

### 6.3 Sales

* `tblSales`
* `tblSalesDetails`
* `tblReceipts`

### 6.4 HR & Payroll

* `tblEmployees`
* `tblDepartments`
* `tblSalaries`
* `tblPayrolls`
* `tblSalarySlips`
* `tblAttendance`

### 6.5 Communication

* `tblMessages`
* `tblAnnouncements`
* `tblNotifications`

### 6.6 File & Media

* `tblUploads`
* `tblBusinessLogos`
* `tblEmployeeDocuments`

### 6.7 Public Interface

* `tblBusinessProfiles`
* `tblProductShowcase`
* `tblPublicReviews`

### 6.8 System Admin & Reporting

* `tblSettings`
* `tblAuditLogs`
* `tblBackups`
* `tblKPIReports`
* `tblFinancialSummaries`

---

## 7. Future Scope

* Mobile app (React Native or Flutter)
* QR/Barcode scanner integration for inventory
* Mpesa & card payment gateway integration
* Email/SMS notification API integration
* User analytics dashboard per role

---

## 8. Conclusion

UBMS provides an all-in-one solution to manage multiple business operations under one system. It reduces manual work, improves data visibility, ensures accountability, and empowers both owners and employees with better tools to operate effectively. Designed to scale, this system will grow as your network of businesses expands.

---

**Prepared by:** SeniorSirRaphael (Mwendwa Raphael)
**Project Title:** Universal Business Management System (UBMS)
**Contact:** [siraphaelmwendwa@gmail.com](mailto:siraphaelmwendwa@gmail.com) | +254 757 319 350
