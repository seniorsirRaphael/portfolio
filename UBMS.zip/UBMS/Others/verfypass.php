<?php
// Debug script to check password hashing
require_once 'config/db_connect.php';

$test_password = 'r4mw10581058';
$hashed_password = password_hash($test_password, PASSWORD_BCRYPT);

echo "Test Password: $test_password\n";
echo "Hashed Version: $hashed_password\n";

// Compare with what's in database
$email = 'james@nairobi-bestmart.com'; // Use an email you're testing with
$query = "SELECT password_hash FROM tblUsers WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "Stored Hash: " . $user['password_hash'] . "\n";
    echo "Verification: " . (password_verify($test_password, $user['password_hash']) ? 'Success' : 'Failed');
} else {
    echo "User not found";
}
?>