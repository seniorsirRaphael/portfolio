document.addEventListener('DOMContentLoaded', function() {
  // DOM Elements
  const loginForm = document.getElementById('loginForm');
  const passwordField = document.getElementById('passwordField');
  const togglePassword = document.getElementById('togglePassword');
  const passwordStrength = document.getElementById('passwordStrength');
  const forgotPasswordLink = document.getElementById('forgotPasswordLink');
  const contactAdminLink = document.getElementById('contactAdminLink');
  const homeButton = document.getElementById('homeButton');
  const contactAdminDialog = document.getElementById('contactAdminDialog');
  const forgotPasswordDialog = document.getElementById('forgotPasswordDialog');
  const closeContactDialog = document.getElementById('closeContactDialog');
  const closeForgotDialog = document.getElementById('closeForgotDialog');
  const contactFromForgotPassword = document.getElementById('contactFromForgotPassword');
  const googleLogin = document.getElementById('googleLogin');
  const microsoftLogin = document.getElementById('microsoftLogin');

  // Password visibility toggle
  if (togglePassword && passwordField) {
    togglePassword.addEventListener('click', () => {
      const isPassword = passwordField.type === 'password';
      passwordField.type = isPassword ? 'text' : 'password';
      togglePassword.name = isPassword ? 'eye-slash' : 'eye';
    });
  }

  // Password strength indicator
  if (passwordField && passwordStrength) {
    passwordField.addEventListener('input', function() {
      const password = this.value;
      let strength = 0;
      
      // Length check
      if (password.length >= 8) strength += 1;
      if (password.length >= 12) strength += 1;
      
      // Complexity checks
      if (/[A-Z]/.test(password)) strength += 1;
      if (/[0-9]/.test(password)) strength += 1;
      if (/[^A-Za-z0-9]/.test(password)) strength += 1;
      
      // Update strength meter
      const strengthPercent = Math.min(100, strength * 20);
      passwordStrength.style.width = `${strengthPercent}%`;
      
      // Update color
      if (strengthPercent < 40) {
        passwordStrength.style.backgroundColor = '#dc3545'; // Red
      } else if (strengthPercent < 70) {
        passwordStrength.style.backgroundColor = '#fd7e14'; // Orange
      } else {
        passwordStrength.style.backgroundColor = '#28a745'; // Green
      }
    });
  }

  // Form submission handling
  if (loginForm) {
    loginForm.addEventListener('submit', function(e) {
      const submitButton = this.querySelector('sl-button[type="submit"]');
      if (submitButton) {
        submitButton.setAttribute('loading', '');
        submitButton.innerHTML = `
          <sl-spinner slot="prefix"></sl-spinner>
          Authenticating...
        `;
      }
    });
  }

  // Dialog controls
  if (forgotPasswordLink && forgotPasswordDialog) {
    forgotPasswordLink.addEventListener('click', (e) => {
      e.preventDefault();
      forgotPasswordDialog.show();
    });
  }

  if (contactAdminLink && contactAdminDialog) {
    contactAdminLink.addEventListener('click', (e) => {
      e.preventDefault();
      contactAdminDialog.show();
    });
  }

  if (closeContactDialog && contactAdminDialog) {
    closeContactDialog.addEventListener('click', () => {
      contactAdminDialog.hide();
    });
  }

  if (closeForgotDialog && forgotPasswordDialog) {
    closeForgotDialog.addEventListener('click', () => {
      forgotPasswordDialog.hide();
    });
  }

  if (contactFromForgotPassword && forgotPasswordDialog && contactAdminDialog) {
    contactFromForgotPassword.addEventListener('click', () => {
      forgotPasswordDialog.hide();
      contactAdminDialog.show();
    });
  }

  // Home button functionality
  if (homeButton) {
    homeButton.addEventListener('click', (e) => {
      e.preventDefault();
      window.location.href = 'index.php';
    });
  }

  // Social login buttons
  if (googleLogin) {
    googleLogin.addEventListener('click', (e) => {
      e.preventDefault();
      showFeatureComingSoon('Google Login');
    });
  }

  if (microsoftLogin) {
    microsoftLogin.addEventListener('click', (e) => {
      e.preventDefault();
      showFeatureComingSoon('Microsoft Login');
    });
  }

  // Helper function for coming soon features
  function showFeatureComingSoon(featureName) {
    const alert = Object.assign(document.createElement('sl-alert'), {
      variant: 'info',
      closable: true,
      duration: 3000,
      innerHTML: `
        <sl-icon name="info-circle" slot="icon"></sl-icon>
        ${featureName} will be available in the next update.
      `
    });
    
    document.body.appendChild(alert);
    alert.toast();
  }

  // Check for logout success message
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has('logout') && urlParams.get('logout') === 'success') {
    const alert = Object.assign(document.createElement('sl-alert'), {
      variant: 'success',
      closable: true,
      duration: 3000,
      innerHTML: `
        <sl-icon name="check2-circle" slot="icon"></sl-icon>
        You have been successfully logged out.
      `
    });
    
    document.body.appendChild(alert);
    alert.toast();
    
    // Clean URL
    history.replaceState(null, '', window.location.pathname);
  }

  // Theme toggle functionality
  const themeToggle = document.createElement('sl-button');
  themeToggle.setAttribute('circle', '');
  themeToggle.setAttribute('size', 'large');
  themeToggle.style.position = 'fixed';
  themeToggle.style.bottom = '20px';
  themeToggle.style.right = '20px';
  themeToggle.innerHTML = `<sl-icon name="moon"></sl-icon>`;
  
  themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    themeToggle.innerHTML = `<sl-icon name="${newTheme === 'dark' ? 'sun' : 'moon'}"></sl-icon>`;
  });

  // Set initial theme
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  themeToggle.innerHTML = `<sl-icon name="${savedTheme === 'dark' ? 'sun' : 'moon'}"></sl-icon>`;
  
  document.body.appendChild(themeToggle);
});