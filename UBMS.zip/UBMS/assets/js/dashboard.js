/**
 * Core Dashboard Functionality
 */

// Toggle sidebar on mobile
function setupSidebarToggle() {
  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.querySelector('.app-sidebar');
  
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
      sidebar.classList.toggle('show');
    });
  }
}

// Initialize tooltips
function initTooltips() {
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
}

// Handle theme switching
function setupThemeSwitcher() {
  const themeSwitcher = document.getElementById('themeSwitcher');
  if (themeSwitcher) {
    themeSwitcher.addEventListener('sl-change', (event) => {
      document.documentElement.setAttribute('data-theme', event.target.value);
      localStorage.setItem('theme', event.target.value);
    });
  }
}

// Initialize dashboard when DOM loads
document.addEventListener('DOMContentLoaded', function() {
  setupSidebarToggle();
  initTooltips();
  setupThemeSwitcher();
  
  // Set active theme from localStorage
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  
  // Hide loading overlay
  const loadingOverlay = document.getElementById('loadingOverlay');
  if (loadingOverlay) {
    setTimeout(() => {
      loadingOverlay.style.display = 'none';
    }, 500);
  }
});

// Show loading state during AJAX operations
function showLoading() {
  const loadingOverlay = document.getElementById('loadingOverlay');
  if (loadingOverlay) {
    loadingOverlay.style.display = 'flex';
  }
}

function hideLoading() {
  const loadingOverlay = document.getElementById('loadingOverlay');
  if (loadingOverlay) {
    loadingOverlay.style.display = 'none';
  }
}

// Export functions for module use
export {
  setupSidebarToggle,
  initTooltips,
  setupThemeSwitcher,
  showLoading,
  hideLoading
};