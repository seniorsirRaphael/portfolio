/**
 * Point of Sale System JavaScript
 */

class POSSystem {
  constructor() {
    this.cart = [];
    this.total = 0;
    this.initElements();
    this.setupEventListeners();
  }

  initElements() {
    this.productGrid = document.getElementById('productGrid');
    this.cartItems = document.getElementById('cartItems');
    this.subtotalEl = document.getElementById('subtotal');
    this.taxEl = document.getElementById('tax');
    this.totalEl = document.getElementById('total');
    this.checkoutBtn = document.getElementById('checkoutBtn');
    this.clearCartBtn = document.getElementById('clearCartBtn');
  }

  setupEventListeners() {
    if (this.productGrid) {
      this.productGrid.addEventListener('click', (e) => {
        const productCard = e.target.closest('.product-card');
        if (productCard) {
          this.addToCart(productCard.dataset.productId, productCard.dataset.productName, parseFloat(productCard.dataset.productPrice));
        }
      });
    }

    if (this.checkoutBtn) {
      this.checkoutBtn.addEventListener('click', () => this.processCheckout());
    }

    if (this.clearCartBtn) {
      this.clearCartBtn.addEventListener('click', () => this.clearCart());
    }
  }

  addToCart(productId, name, price) {
    const existingItem = this.cart.find(item => item.id === productId);
    
    if (existingItem) {
      existingItem.quantity++;
    } else {
      this.cart.push({
        id: productId,
        name: name,
        price: price,
        quantity: 1
      });
    }
    
    this.updateCartDisplay();
  }

  updateCartDisplay() {
    this.cartItems.innerHTML = '';
    this.total = 0;
    
    this.cart.forEach(item => {
      const itemTotal = item.price * item.quantity;
      this.total += itemTotal;
      
      const li = document.createElement('li');
      li.className = 'cart-item';
      li.innerHTML = `
        <div class="item-info">
          <span class="item-name">${item.name}</span>
          <span class="item-price">KES ${item.price.toFixed(2)}</span>
        </div>
        <div class="item-controls">
          <sl-button size="small" circle data-action="decrease" data-id="${item.id}">
            <sl-icon name="dash"></sl-icon>
          </sl-button>
          <span class="quantity">${item.quantity}</span>
          <sl-button size="small" circle data-action="increase" data-id="${item.id}">
            <sl-icon name="plus"></sl-icon>
          </sl-button>
          <sl-button size="small" circle data-action="remove" data-id="${item.id}">
            <sl-icon name="trash"></sl-icon>
          </sl-button>
        </div>
      `;
      this.cartItems.appendChild(li);
    });
    
    const tax = this.total * 0.16; // 16% VAT
    const subtotal = this.total;
    const total = subtotal + tax;
    
    this.subtotalEl.textContent = `KES ${subtotal.toFixed(2)}`;
    this.taxEl.textContent = `KES ${tax.toFixed(2)}`;
    this.totalEl.textContent = `KES ${total.toFixed(2)}`;
  }

  processCheckout() {
    if (this.cart.length === 0) {
      this.showToast('Cart is empty', 'warning');
      return;
    }
    
    // In a real app, you would send this to your backend
    const saleData = {
      items: this.cart,
      subtotal: this.total,
      tax: this.total * 0.16,
      total: this.total * 1.16,
      timestamp: new Date().toISOString()
    };
    
    console.log('Processing sale:', saleData);
    this.showToast('Sale processed successfully', 'success');
    this.clearCart();
  }

  clearCart() {
    this.cart = [];
    this.updateCartDisplay();
  }

  showToast(message, variant = 'primary') {
    const toast = Object.assign(document.createElement('sl-alert'), {
      variant: variant,
      closable: true,
      duration: 3000,
      innerHTML: message
    });
    
    document.body.appendChild(toast);
    toast.toast();
  }
}

// Initialize POS when DOM loads
document.addEventListener('DOMContentLoaded', () => {
  if (document.querySelector('.pos-interface')) {
    new POSSystem();
  }
});