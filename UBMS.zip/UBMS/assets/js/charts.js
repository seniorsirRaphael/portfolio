/**
 * Chart Initialization and Management
 */

// Initialize sales chart
function initSalesChart() {
  const ctx = document.getElementById('salesChart');
  if (!ctx) return;

  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
      datasets: [{
        label: 'Monthly Sales',
        data: [12000, 19000, 15000, 22000, 18000, 25000, 30000],
        borderColor: '#4361ee',
        backgroundColor: 'rgba(67, 97, 238, 0.1)',
        borderWidth: 2,
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'top',
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return 'KES ' + context.parsed.y.toLocaleString();
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return 'KES ' + value.toLocaleString();
            }
          }
        }
      }
    }
  });
}

// Initialize inventory chart
function initInventoryChart() {
  const ctx = document.getElementById('inventoryChart');
  if (!ctx) return;

  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['In Stock', 'Low Stock', 'Out of Stock'],
      datasets: [{
        data: [65, 15, 5],
        backgroundColor: [
          '#4cc9f0',
          '#f8961e',
          '#f72585'
        ],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      cutout: '70%',
      plugins: {
        legend: {
          position: 'bottom',
        }
      }
    }
  });
}

// Initialize all charts
function initAllCharts() {
  initSalesChart();
  initInventoryChart();
}

// Export functions
export {
  initSalesChart,
  initInventoryChart,
  initAllCharts
};