<?php
require_once 'config/db_connect.php';
require_once 'includes/session_manager.php';

$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();

// Record logout in database if user is logged in
if (isset($_SESSION['user']['id'])) {
    $user_id = $_SESSION['user']['id'];
    $query = "UPDATE tblUsers SET last_logout = NOW() WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    
    // Record logout activity
    $activityQuery = "INSERT INTO tblUserActivities (user_id, activity_type, description) 
                     VALUES (?, 'logout', 'User logged out')";
    $stmt = $conn->prepare($activityQuery);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
}

// Destroy the session
$sessionManager->destroySession();

// Redirect to login page with success message
header("Location: login.php?logout=success");
exit();
?>