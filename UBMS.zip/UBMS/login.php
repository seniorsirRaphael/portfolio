<?php
require_once 'config/db_connect.php';
require_once 'includes/session_manager.php';

$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();

// Check if already logged in
if ($sessionManager->isLoggedIn()) {
    header('Location: dashboard/'); // Updated to new dashboard location
    exit();
}

// Initialize variables
$email = $password = '';
$error = '';
$loginAttempts = 0;

// Process login form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize inputs
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $remember = isset($_POST['remember']);

    // Validate inputs
    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password';
    } else {
        // Check login attempts
        $ip = $_SERVER['REMOTE_ADDR'];
        $attemptsQuery = "SELECT COUNT(*) AS attempts 
                         FROM tblLoginAttempts 
                         WHERE ip_address = ? 
                         AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
                         AND is_successful = 0";
        $stmt = $conn->prepare($attemptsQuery);
        $stmt->bind_param('s', $ip);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $loginAttempts = $row['attempts'];

        if ($loginAttempts >= 5) {
            $error = 'Too many failed attempts. Please try again in 15 minutes.';
        } else {
            // Get user from database
            $query = "SELECT u.*, r.role_name, r.role_level, b.business_name, b.logo_path
                     FROM tblUsers u
                     JOIN tblRoles r ON u.role_id = r.role_id
                     LEFT JOIN tblBusinesses b ON u.business_id = b.business_id
                     WHERE u.email = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                // Check account status
                if ($user['status'] !== 'Active') {
                    $error = 'Your account is ' . strtolower($user['status']) . '. Please contact administrator.';
                    
                    // Record failed attempt
                    $attemptQuery = "INSERT INTO tblLoginAttempts (user_id, ip_address, is_successful) 
                                   VALUES (?, ?, 0)";
                    $stmt = $conn->prepare($attemptQuery);
                    $stmt->bind_param('is', $user['user_id'], $ip);
                    $stmt->execute();
                }
                // Verify password
                elseif (password_verify($password, $user['password_hash'])) {
                    // Create session
                    if ($sessionManager->createLoginSession($user['user_id'], $remember)) {
                        // Set user data in session
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['full_name'] = $user['full_name'];
                        $_SESSION['role_level'] = $user['role_level'];
                        $_SESSION['business_id'] = $user['business_id'];
                        $_SESSION['business_name'] = $user['business_name'];
                        $_SESSION['business_logo'] = $user['logo_path'];
                        
                        // Record successful attempt
                        $attemptQuery = "INSERT INTO tblLoginAttempts (user_id, ip_address, is_successful) 
                                       VALUES (?, ?, 1)";
                        $stmt = $conn->prepare($attemptQuery);
                        $stmt->bind_param('is', $user['user_id'], $ip);
                        $stmt->execute();
                        
                        // Redirect to dashboard (updated location)
                        header('Location: dashboard/');
                        exit();
                    } else {
                        $error = 'System error during login. Please try again.';
                    }
                } else {
                    // Invalid password
                    $error = 'Invalid email or password';
                    
                    // Record failed attempt
                    $attemptQuery = "INSERT INTO tblLoginAttempts (user_id, ip_address, is_successful) 
                                   VALUES (?, ?, 0)";
                    $stmt = $conn->prepare($attemptQuery);
                    $stmt->bind_param('is', $user['user_id'], $ip);
                    $stmt->execute();
                    
                    // Update failed attempts count
                    $updateQuery = "UPDATE tblUsers 
                                  SET failed_login_attempts = failed_login_attempts + 1
                                  WHERE user_id = ?";
                    $stmt = $conn->prepare($updateQuery);
                    $stmt->bind_param('i', $user['user_id']);
                    $stmt->execute();
                    
                    // Lock account if too many attempts
                    if ($user['failed_login_attempts'] + 1 >= 5) {
                        $lockQuery = "UPDATE tblUsers 
                                     SET account_locked_until = DATE_ADD(NOW(), INTERVAL 15 MINUTE)
                                     WHERE user_id = ?";
                        $stmt = $conn->prepare($lockQuery);
                        $stmt->bind_param('i', $user['user_id']);
                        $stmt->execute();
                        $error = 'Too many failed attempts. Account locked for 15 minutes.';
                    }
                }
            } else {
                // User not found
                $error = 'Invalid email or password';
                
                // Record failed attempt
                $attemptQuery = "INSERT INTO tblLoginAttempts (ip_address, is_successful) 
                                VALUES (?, 0)";
                $stmt = $conn->prepare($attemptQuery);
                $stmt->bind_param('s', $ip);
                $stmt->execute();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>UBMS | Login</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.8/sweetalert2.min.css">
  <style>
    :root {
      --primary-color: #3498db;
      --primary-dark: #2980b9;
      --secondary-color: #6c757d;
      --success-color: #28a745;
      --danger-color: #dc3545;
      --warning-color: #f8961e;
      --dark-bg: #1a1a2e;
      --dark-card: #16213e;
      --light-bg: #f8f9fa;
      --text-dark: #212529;
      --text-light: #f8f9fa;
    }
    
    body {
      background-color: var(--light-bg);
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .login-container {
      max-width: 500px;
      margin: auto;
      padding: 2.5rem;
      border-radius: 12px;
      box-shadow: 0 10px 30px rgba(0,0,0,0.08);
      background-color: white;
      position: relative;
      overflow: hidden;
    }
    
    .login-container::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 5px;
      background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
    }
    
    .login-header {
      text-align: center;
      margin-bottom: 2.5rem;
    }
    
    .login-logo {
      width: 120px;
      height: 120px;
      object-fit: contain;
      margin-bottom: 1.5rem;
      transition: transform 0.3s ease;
    }
    
    .login-logo:hover {
      transform: scale(1.05);
    }
    
    .btn-login {
      background-color: var(--primary-color);
      border: none;
      padding: 0.75rem;
      font-weight: 500;
      letter-spacing: 0.5px;
      transition: all 0.3s ease;
    }
    
    .btn-login:hover {
      background-color: var(--primary-dark);
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(41, 128, 185, 0.3);
    }
    
    .form-control:focus {
      border-color: var(--primary-color);
      box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
    }
    
    .dark-mode .login-container {
      background-color: var(--dark-card);
      color: var(--text-light);
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }
    
    .dark-mode body {
      background-color: var(--dark-bg);
    }
    
    .dark-mode .form-control, 
    .dark-mode .input-group-text {
      background-color: rgba(255,255,255,0.05);
      border-color: #2c3e50;
      color: var(--text-light);
    }
    
    .password-toggle {
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      color: var(--secondary-color);
      transition: color 0.2s ease;
    }
    
    .password-toggle:hover {
      color: var(--primary-color);
    }
    
    .password-strength {
      height: 4px;
      width: 0;
      background: var(--danger-color);
      transition: all 0.3s ease;
      border-radius: 2px;
      margin-top: 5px;
    }
    
    .password-requirements {
      font-size: 0.85rem;
      color: var(--secondary-color);
      margin-top: 5px;
    }
    
    .password-requirements.valid {
      color: var(--success-color);
    }
    
    .floating-label {
      position: relative;
      margin-bottom: 1.5rem;
    }
    
    .floating-label label {
      position: absolute;
      top: 12px;
      left: 45px;
      color: var(--secondary-color);
      transition: all 0.2s ease;
      pointer-events: none;
      background-color: white;
      padding: 0 5px;
    }
    
    .floating-label input:focus + label,
    .floating-label input:not(:placeholder-shown) + label {
      top: -10px;
      left: 40px;
      font-size: 0.8rem;
      color: var(--primary-color);
    }
    
    .dark-mode .floating-label label {
      background-color: var(--dark-card);
    }
    
    .social-login {
      display: flex;
      justify-content: center;
      gap: 1rem;
      margin-top: 1.5rem;
    }
    
    .social-btn {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      transition: all 0.3s ease;
    }
    
    .social-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .bg-google {
      background-color: #db4437;
    }
    
    .bg-facebook {
      background-color: #4267B2;
    }
    
    .bg-microsoft {
      background-color: #00A1F1;
    }
    
    .theme-toggle {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background-color: var(--primary-color);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      z-index: 100;
      transition: all 0.3s ease;
    }
    
    .theme-toggle:hover {
      transform: scale(1.1);
    }

    /* New back to home button */
    .home-button {
      position: absolute;
      top: 20px;
      left: 20px;
      z-index: 100;
    }
  </style>
</head>
<body class="<?= isset($_COOKIE['darkMode']) && $_COOKIE['darkMode'] === 'true' ? 'dark-mode' : '' ?>">
  <a href="index.php" class="btn btn-outline-primary home-button animate__animated animate__fadeIn">
    <i class="fas fa-arrow-left me-2"></i> Back to Home
  </a>

  <div class="container my-auto py-5">
    <div class="login-container animate__animated animate__fadeIn">
      <div class="login-header">
        <img src="assets/images/logo.png" alt="UBMS Logo" class="login-logo">
        <h2 class="fw-bold">Welcome Back</h2>
        <p class="text-muted">Sign in to access your UBMS dashboard</p>
      </div>
      
      <?php if (!empty($error)): ?>
        <div class="alert alert-danger animate__animated animate__shakeX d-flex align-items-center">
          <i class="fas fa-exclamation-circle me-2"></i>
          <div>
            <?= htmlspecialchars($error) ?>
            <?php if ($loginAttempts >= 3): ?>
              <div class="mt-1 small">You've had <?= $loginAttempts ?> failed attempts.</div>
            <?php endif; ?>
          </div>
        </div>
      <?php endif; ?>
      
      <form action="login.php" method="POST" id="loginForm" novalidate>
        <div class="mb-4 floating-label">
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" class="form-control" id="email" name="email" 
                   value="<?= htmlspecialchars($email) ?>" required
                   placeholder=" " autocomplete="username">
            <label for="email">Email Address</label>
          </div>
        </div>
        
        <div class="mb-4 floating-label position-relative">
          <div class="input-group">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" class="form-control" id="password" name="password" 
                   required placeholder=" " autocomplete="current-password"
                   minlength="8">
            <label for="password">Password</label>
            <i class="fas fa-eye-slash password-toggle" id="togglePassword"></i>
          </div>
          <div class="password-strength" id="passwordStrength"></div>
          <div class="password-requirements" id="passwordHelp">
            Password must be at least 8 characters long
          </div>
          <div class="text-end mt-1">
            <a href="#" id="forgotPassword" class="text-decoration-none small">Forgot password?</a>
          </div>
        </div>
        
        <div class="mb-4 form-check d-flex justify-content-between align-items-center">
          <div>
            <input type="checkbox" class="form-check-input" id="remember" name="remember">
            <label class="form-check-label" for="remember">Remember me</label>
          </div>
          <div>
            <a href="#" id="contactAdmin" class="text-decoration-none small">Contact Administrator</a>
          </div>
        </div>
        
        <div class="d-grid gap-2 mb-4">
          <button type="submit" class="btn btn-primary btn-login">
            <i class="fas fa-sign-in-alt me-2"></i> Login
          </button>
        </div>
        
        <div class="position-relative text-center mb-4">
          <hr>
          <span class="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted">or</span>
        </div>
        
        <div class="social-login">
          <a href="#" class="social-btn bg-google" title="Sign in with Google">
            <i class="fab fa-google"></i>
          </a>
          <a href="#" class="social-btn bg-facebook" title="Sign in with Facebook">
            <i class="fab fa-facebook-f"></i>
          </a>
          <a href="#" class="social-btn bg-microsoft" title="Sign in with Microsoft">
            <i class="fab fa-microsoft"></i>
          </a>
        </div>
      </form>
    </div>
  </div>

  <div class="theme-toggle animate__animated animate__fadeInRight" id="themeToggle">
    <i class="fas fa-moon"></i>
  </div>

  <footer class="bg-dark text-white text-center py-3 mt-auto">
    <p class="mb-0 small">&copy; <?= date('Y') ?> Universal Business Management System (UBMS). All rights reserved.</p>
  </footer>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.4.8/sweetalert2.min.js"></script>
  <script>
  $(document).ready(function() {
    // Password toggle
    $('#togglePassword').click(function() {
      const passwordField = $('#password');
      const icon = $(this);

      if (passwordField.attr('type') === 'password') {
        passwordField.attr('type', 'text');
        icon.removeClass('fa-eye-slash').addClass('fa-eye');
      } else {
        passwordField.attr('type', 'password');
        icon.removeClass('fa-eye').addClass('fa-eye-slash');
      }
    });

    // Password strength indicator
    $('#password').on('input', function() {
      const password = $(this).val();
      const strengthBar = $('#passwordStrength');
      const helpText = $('#passwordHelp');

      if (password.length === 0) {
        strengthBar.width('0');
        helpText.removeClass('valid');
        return;
      }

      if (password.length < 8) {
        strengthBar.width('30%').css('background-color', 'var(--danger-color)');
        helpText.removeClass('valid');
      } else if (password.length < 12) {
        strengthBar.width('60%').css('background-color', 'orange');
        helpText.removeClass('valid');
      } else {
        strengthBar.width('100%').css('background-color', 'var(--success-color)');
        helpText.addClass('valid');
      }
    });

    // Theme toggle
    function updateThemeIcon() {
      const icon = $('#themeToggle i');
      if ($('body').hasClass('dark-mode')) {
        icon.removeClass('fa-moon').addClass('fa-sun');
        localStorage.setItem('darkMode', 'true');
      } else {
        icon.removeClass('fa-sun').addClass('fa-moon');
        localStorage.setItem('darkMode', 'false');
      }
    }

    if (localStorage.getItem('darkMode') === 'true') {
      $('body').addClass('dark-mode');
      updateThemeIcon();
    }

    $('#themeToggle').click(function() {
      $('body').toggleClass('dark-mode');
      updateThemeIcon();
    });

    // Form submission
    $('#loginForm').submit(function() {
      $('.btn-login').html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Authenticating...');
      $('.btn-login').prop('disabled', true);
    });

    // Contact Admin popup
    $('#contactAdmin').click(function(e) {
      e.preventDefault();
      Swal.fire({
        title: 'Contact Administrator',
        html: `
          <div class="text-start">
            <p>Please contact the system administrator for account access:</p>
            <ul class="list-unstyled">
              <li><i class="fas fa-user me-2"></i> Raphael Mwendwa</li>
              <li><i class="fas fa-envelope me-2"></i> admin@ubms.com</li>
              <li><i class="fas fa-phone me-2"></i> +254 757 319 350</li>
              <li><i class="fas fa-building me-2"></i> UBMS Headquarters, Nairobi</li>
            </ul>
          </div>
        `,
        icon: 'info',
        confirmButtonText: 'OK',
        confirmButtonColor: 'var(--primary-color)',
        backdrop: 'rgba(0,0,0,0.4)'
      });
    });

    // Forgot Password popup
    $('#forgotPassword').click(function(e) {
      e.preventDefault();
      Swal.fire({
        title: 'Forgot Password?',
        html: `
          <div class="text-start">
            <p>For security reasons, password resets must be initiated by the system administrator.</p>
            <p>Please contact your administrator with the following details:</p>
            <ul>
              <li>Your full name</li>
              <li>Registered email address</li>
              <li>Business name</li>
            </ul>
            <p>You can contact them at <strong>admin@ubms.com</strong> or call <strong>+254 757 319 350</strong></p>
          </div>
        `,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Contact Admin',
        cancelButtonText: 'Back to Login',
        confirmButtonColor: 'var(--primary-color)',
        cancelButtonColor: 'var(--secondary-color)'
      }).then((result) => {
        if (result.isConfirmed) {
          $('#contactAdmin').trigger('click');
        }
      });
    });

    // Social login buttons
    $('.social-btn').click(function(e) {
      e.preventDefault();
      Swal.fire({
        title: 'Social Login',
        text: 'This feature will be available in the next update',
        icon: 'info',
        confirmButtonText: 'OK',
        confirmButtonColor: 'var(--primary-color)'
      });
    });

    // Floating labels
    $('.floating-label input').each(function() {
      if ($(this).val() !== '') {
        $(this).next('label').addClass('active');
      }
    });
  });
  </script>
</body>
</html>