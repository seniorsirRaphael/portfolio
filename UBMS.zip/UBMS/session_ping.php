<?php
require_once 'config/db_connect.php';
require_once 'includes/session_manager.php';

$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();

// Just by accessing this file, the session will be updated
die('OK');
?>