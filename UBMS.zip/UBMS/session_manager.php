<?php
// session_manager.php

session_start();

// Optional: Customize session timeout
$timeout_duration = 1800; // 30 minutes

// If session timestamp is set, check if the session has expired
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();     // Unset $_SESSION variable
    session_destroy();   // Destroy session data
    header("Location: login.php?timeout=1");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time(); // Update last activity timestamp

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role_level'])) {
    header("Location: login.php?unauthorized=1");
    exit();
}

// Optional: role-based access check
function requireRole($roles = []) {
    if (!in_array($_SESSION['role_level'], $roles)) {
        header("Location: unauthorized.php");
        exit();
    }
}

// Example usage (in dashboard.php or any protected page):
// requireRole(['SuperAdmin', 'Manager']);

?>
