<?php
session_start();

// Database connection
require_once 'config/db_connect.php';

class SessionManager {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function checkSession() {
        if (!isset($_SESSION['user_id'])) {
            header("Location: login.php");
            exit();
        }
        
        // Check if session is still valid in database
        $user_id = $_SESSION['user_id'];
        $query = "SELECT status FROM tblUsers WHERE user_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $this->destroySession();
            header("Location: login.php?error=session_expired");
            exit();
        }
        
        $user = $result->fetch_assoc();
        if ($user['status'] !== 'Active') {
            $this->destroySession();
            header("Location: login.php?error=account_inactive");
            exit();
        }
    }
    
    public function checkRole($required_roles) {
        if (!isset($_SESSION['role_id'])) {
            $this->destroySession();
            header("Location: login.php?error=unauthorized");
            exit();
        }
        
        // Convert single role to array for uniform handling
        if (!is_array($required_roles)) {
            $required_roles = [$required_roles];
        }
        
        // Get user's role level from database
        $role_id = $_SESSION['role_id'];
        $query = "SELECT role_level FROM tblRoles WHERE role_id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("i", $role_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $this->destroySession();
            header("Location: login.php?error=invalid_role");
            exit();
        }
        
        $role = $result->fetch_assoc();
        $user_role_level = $role['role_level'];
        
        // Check if user has sufficient privileges
        $role_hierarchy = ['SuperAdmin', 'Manager', 'Employee', 'Staff'];
        $user_level_index = array_search($user_role_level, $role_hierarchy);
        
        $has_access = false;
        foreach ($required_roles as $required_role) {
            $required_level_index = array_search($required_role, $role_hierarchy);
            if ($user_level_index <= $required_level_index) {
                $has_access = true;
                break;
            }
        }
        
        if (!$has_access) {
            header("Location: unauthorized.php");
            exit();
        }
    }
    
    public function destroySession() {
        // Unset all session variables
        $_SESSION = array();
        
        // Destroy the session
        session_destroy();
        
        // Delete the session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
    }
}

// Initialize session manager
$sessionManager = new SessionManager($conn);

// Check session on all pages that require authentication
// Usage: $sessionManager->checkSession();
// Usage: $sessionManager->checkRole(['Manager', 'SuperAdmin']);
?>