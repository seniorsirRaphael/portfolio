<?php
// Database configuration
$host = 'localhost';         // or 127.0.0.1
$db   = 'ubms_db';           // your database name
$user = 'root';              // your MySQL username
$pass = 'r4mw10581058';                  // your MySQL password (set if any)
$charset = 'utf8mb4';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Optional: Set charset
$conn->set_charset($charset);
?>
