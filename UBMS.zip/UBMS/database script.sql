-- ================================
-- UNIVERSAL BUSINESS MANAGEMENT SYSTEM (UBMS)
-- ================================
CREATE DATABASE IF NOT EXISTS ubms_db;
USE ubms_db;

-- 1. Businesses
CREATE TABLE tblBusinesses (
    business_id INT AUTO_INCREMENT PRIMARY KEY,
    business_name VARCHAR(100) NOT NULL,
    business_type ENUM('Retail','Hospitality','Service','Manufacturing','Other') NOT NULL,
    location VARCHAR(150),
    contact_email VARCHAR(100) UNIQUE,
    contact_phone VARCHAR(20) UNIQUE,
    logo_path VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_business_active (is_active)
) ENGINE=InnoDB;

-- 2. Roles
CREATE TABLE tblRoles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) UNIQUE NOT NULL,
    role_level ENUM('SuperAdmin','Manager','Employee','Staff') NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Users
CREATE TABLE tblUsers (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    last_login DATETIME,
    status ENUM('Active','Inactive','Suspended') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE SET NULL,
    FOREIGN KEY (role_id) REFERENCES tblRoles(role_id),
    INDEX idx_user_email (email),
    INDEX idx_user_business (business_id)
) ENGINE=InnoDB;

-- 4. Categories
CREATE TABLE tblCategories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    category_name VARCHAR(100) NOT NULL,
    parent_category_id INT NULL,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE CASCADE,
    FOREIGN KEY (parent_category_id) REFERENCES tblCategories(category_id) ON DELETE SET NULL,
    UNIQUE KEY uk_category_business (business_id, category_name)
) ENGINE=InnoDB;

-- 5. Products
CREATE TABLE tblProducts (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    category_id INT,
    product_code VARCHAR(50) UNIQUE,
    product_name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    cost_price DECIMAL(10,2),
    quantity INT NOT NULL DEFAULT 0,
    low_stock_threshold INT DEFAULT 5,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES tblCategories(category_id) ON DELETE SET NULL,
    INDEX idx_product_business (business_id),
    INDEX idx_product_category (category_id)
) ENGINE=InnoDB;

-- 6. Sales
CREATE TABLE tblSales (
    sale_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    user_id INT NOT NULL,
    customer_name VARCHAR(100),
    customer_contact VARCHAR(20),
    sale_total DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) DEFAULT 0.00,
    tax_amount DECIMAL(10,2) DEFAULT 0.00,
    payment_method ENUM('Cash','Card','MobileMoney','Credit') NOT NULL,
    payment_status ENUM('Paid','Pending','PartiallyPaid') DEFAULT 'Paid',
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES tblUsers(user_id) ON DELETE RESTRICT,
    INDEX idx_sale_business (business_id),
    INDEX idx_sale_date (sale_date)
) ENGINE=InnoDB;

-- 7. Sale Details (Line Items)
CREATE TABLE tblSalesDetails (
    detail_id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES tblSales(sale_id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES tblProducts(product_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. Departments
CREATE TABLE tblDepartments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    department_name VARCHAR(100) NOT NULL,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE CASCADE,
    UNIQUE KEY uk_dept_business (business_id, department_name)
) ENGINE=InnoDB;

-- 9. Employees
CREATE TABLE tblEmployees (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    department_id INT,
    employee_code VARCHAR(20) UNIQUE,
    position VARCHAR(100),
    salary DECIMAL(10,2) NOT NULL,
    hire_date DATE NOT NULL,
    termination_date DATE,
    emergency_contact VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES tblUsers(user_id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES tblDepartments(department_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 10. Salaries
CREATE TABLE tblSalaries (
    salary_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    month VARCHAR(20),
    basic DECIMAL(10,2),
    allowances DECIMAL(10,2),
    deductions DECIMAL(10,2),
    total DECIMAL(10,2),
    status ENUM('Paid','Pending','Rejected') DEFAULT 'Pending',
    slip_path VARCHAR(255),
    processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES tblEmployees(employee_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 11. Announcements
CREATE TABLE tblAnnouncements (
    announcement_id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT,
    title VARCHAR(150),
    message TEXT,
    image_path VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES tblBusinesses(business_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 12. Internal Messages
CREATE TABLE tblMessages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT,
    recipient_id INT,
    message TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES tblUsers(user_id),
    FOREIGN KEY (recipient_id) REFERENCES tblUsers(user_id)
) ENGINE=InnoDB;

-- 13. Login Attempts
CREATE TABLE tblLoginAttempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    ip_address VARCHAR(45) NOT NULL,
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_successful BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES tblUsers(user_id) ON DELETE CASCADE,
    INDEX idx_login_attempts (user_id, attempt_time)
) ENGINE=InnoDB;

-- 14. Password Reset Tokens
CREATE TABLE tblPasswordResetTokens (
    token_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES tblUsers(user_id) ON DELETE CASCADE,
    INDEX idx_reset_token (token)
) ENGINE=InnoDB;
