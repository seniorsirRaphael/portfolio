<?php require 'common/header.php'; ?>
<?php require 'common/sidebar.php'; ?>

<main class="app-main">
    <!-- Header Content -->
    <header class="app-header">
        <div class="header-left">
            <sl-button variant="default" circle id="sidebarToggle">
                <sl-icon name="list"></sl-icon>
            </sl-button>
            <h2>Admin Dashboard</h2>
        </div>
        <div class="header-right">
            <!-- User dropdown -->
        </div>
    </header>
    
    <!-- Dashboard Content -->
    <div class="app-content">
        <div class="welcome-banner animate__animated animate__fadeIn">
            <div class="welcome-content">
                <h1>Welcome, <?= htmlspecialchars($user['full_name']) ?></h1>
                <p class="text-muted">
                    <?= date('l, F j, Y') ?>
                    <?php if ($user['business_id']): ?>
                        | <?= htmlspecialchars($user['business_name']) ?>
                    <?php endif; ?>
                </p>
            </div>
            <div class="welcome-actions">
                <sl-button-group>
                    <sl-button variant="primary">
                        <sl-icon name="plus-circle" slot="prefix"></sl-icon>
                        Quick Action
                    </sl-button>
                    <sl-dropdown>
                        <sl-button slot="trigger" variant="primary" caret></sl-button>
                        <sl-menu>
                            <sl-menu-item>Add Business</sl-menu-item>
                            <sl-menu-item>Add User</sl-menu-item>
                            <sl-menu-item>Generate Report</sl-menu-item>
                        </sl-menu>
                    </sl-dropdown>
                </sl-button-group>
            </div>
        </div>
        
        <!-- Admin Stats -->
        <div class="stats-grid">
            <!-- Business stats cards -->
        </div>
        
        <!-- Admin Charts -->
        <div class="chart-row">
            <!-- Business performance charts -->
        </div>
    </div>
</main>

<?php require 'common/footer.php'; ?>