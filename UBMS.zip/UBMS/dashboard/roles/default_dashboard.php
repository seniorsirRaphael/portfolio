<?php require 'common/header.php'; ?>
<?php require 'common/sidebar.php'; ?>

<main class="app-main">
    <header class="app-header">
        <div class="header-left">
            <sl-button variant="default" circle id="sidebarToggle">
                <sl-icon name="list"></sl-icon>
            </sl-button>
            <h2>Dashboard</h2>
        </div>
    </header>
    
    <div class="app-content">
        <div class="welcome-banner animate__animated animate__fadeIn">
            <h1>Welcome to UBMS</h1>
            <p class="text-muted">You don't have a specialized dashboard assigned</p>
        </div>
        
        <div class="empty-state">
            <sl-icon name="person-badge" style="font-size: 3rem;"></sl-icon>
            <h3>No Dashboard Assigned</h3>
            <p>Please contact your administrator to get proper access</p>
            <sl-button variant="primary" href="../profile.php">
                <sl-icon name="person" slot="prefix"></sl-icon>
                View Profile
            </sl-button>
        </div>
    </div>
</main>

<?php require 'common/footer.php'; ?>