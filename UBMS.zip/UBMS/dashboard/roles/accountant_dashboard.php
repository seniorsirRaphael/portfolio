<?php require 'common/header.php'; ?>

<!-- Custom Cashier Sidebar -->
<aside class="app-sidebar cashier-sidebar">
    <div class="sidebar-header">
        <img src="<?= $user['logo_path'] ? '../uploads/'.htmlspecialchars($user['logo_path']) : '../assets/images/logo.png' ?>" 
             alt="Business Logo" class="sidebar-logo">
        <h3><?= htmlspecialchars($user['business_name'] ?? 'POS System') ?></h3>
    </div>
    
    <sl-tab-group placement="start">
        <sl-tab slot="nav" panel="pos" active>
            <sl-icon name="cash-coin"></sl-icon>
            <span>POS</span>
        </sl-tab>
        <sl-tab slot="nav" panel="quick-products">
            <sl-icon name="box-seam"></sl-icon>
            <span>Products</span>
        </sl-tab>
    </sl-tab-group>
    
    <div class="sidebar-footer">
        <sl-button variant="primary" outline full href="../logout.php">
            <sl-icon name="box-arrow-right"></sl-icon>
            Logout
        </sl-button>
    </div>
</aside>

<main class="app-main">
    <header class="app-header">
        <div class="header-left">
            <sl-button variant="default" circle id="sidebarToggle">
                <sl-icon name="list"></sl-icon>
            </sl-button>
            <h2>Point of Sale</h2>
        </div>
        <div class="header-right">
            <sl-button variant="success" circle>
                <sl-icon name="receipt"></sl-icon>
            </sl-button>
        </div>
    </header>
    
    <div class="app-content">
        <?php include '../modules/pos/pos_interface.php'; ?>
    </div>
</main>

<?php require 'common/footer.php'; ?>