<?php
require_once '../config/db_connect.php';
require_once '../includes/session_manager.php';
require_once '../includes/helpers.php';

$sessionManager = new SessionManager($conn);
$sessionManager->startSecureSession();
$sessionManager->checkSession();

// Get user data with business info
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT u.*, r.role_name, r.role_level, b.business_name, b.logo_path 
    FROM tblUsers u
    JOIN tblRoles r ON u.role_id = r.role_id
    LEFT JOIN tblBusinesses b ON u.business_id = b.business_id
    WHERE u.user_id = ?
");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get business stats if applicable
$business_stats = [];
if ($user['business_id']) {
    $stats_query = "
        SELECT 
            (SELECT COUNT(*) FROM tblProducts WHERE business_id = ?) as product_count,
            (SELECT COUNT(*) FROM tblEmployees WHERE business_id = ?) as employee_count,
            (SELECT SUM(sale_total) FROM tblSales WHERE business_id = ? AND MONTH(sale_date) = MONTH(CURRENT_DATE())) as monthly_sales
    ";
    $stmt = $conn->prepare($stats_query);
    $stmt->bind_param('iii', $user['business_id'], $user['business_id'], $user['business_id']);
    $stmt->execute();
    $business_stats = $stmt->get_result()->fetch_assoc();
}

// Route to appropriate dashboard
$roleMap = [
    'SuperAdmin' => 'admin',
    'Admin' => 'admin',
    'Cashier' => 'cashier',
    'Accountant' => 'accountant',
    'Manager' => 'manager'
];

$dashboardFile = 'roles/' . ($roleMap[$user['role_name']] ?? 'default') . '_dashboard.php';

if (file_exists($dashboardFile)) {
    require $dashboardFile;
} else {
    require 'roles/default_dashboard.php';
}
?>