    </div> <!-- Close app-container -->

    <!-- JavaScript Libraries -->
    <script type="module" src="https://cdn.jsdelivr.net/npm/@shoelace-style/shoelace@2.0.0-beta.64/dist/shoelace/shoelace.esm.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/luxon@3.0.1/build/global/luxon.min.js"></script>
    
    <!-- Custom JS -->
    <script src="../assets/js/dashboard.js"></script>
    
    <script>
    // Initialize dashboard
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('loadingOverlay').style.display = 'none';
        
        // Session ping every 5 minutes
        setInterval(() => {
            axios.get('../includes/session_ping.php')
                .catch(() => window.location.href = '../login.php?error=session_expired');
        }, 300000);
    });
    </script>
</body>
</html>