<aside class="app-sidebar">
    <div class="sidebar-header">
        <img src="<?= $user['logo_path'] ? '../uploads/'.htmlspecialchars($user['logo_path']) : '../assets/images/logo.png' ?>" 
             alt="Business Logo" class="sidebar-logo">
        <h3><?= htmlspecialchars($user['business_name'] ?? 'UBMS Portal') ?></h3>
    </div>
    
    <sl-tab-group placement="start">
        <sl-tab slot="nav" panel="dashboard" active>
            <sl-icon name="speedometer2"></sl-icon>
            <span>Dashboard</span>
        </sl-tab>
        
        <?php if ($user['role_level'] >= 3): ?>
        <sl-tab slot="nav" panel="business">
            <sl-icon name="building"></sl-icon>
            <span>Businesses</span>
        </sl-tab>
        <?php endif; ?>
        
        <?php if ($user['role_name'] === 'Cashier'): ?>
        <sl-tab slot="nav" panel="pos">
            <sl-icon name="cash-coin"></sl-icon>
            <span>POS</span>
        </sl-tab>
        <?php endif; ?>
        
        <?php if ($user['role_name'] === 'Accountant'): ?>
        <sl-tab slot="nav" panel="accounting">
            <sl-icon name="calculator"></sl-icon>
            <span>Accounting</span>
        </sl-tab>
        <?php endif; ?>
        
        <sl-tab slot="nav" panel="settings">
            <sl-icon name="gear"></sl-icon>
            <span>Settings</span>
        </sl-tab>
    </sl-tab-group>
    
    <div class="sidebar-footer">
        <sl-button variant="primary" outline full href="../logout.php">
            <sl-icon name="box-arrow-right"></sl-icon>
            Logout
        </sl-button>
    </div>
</aside>